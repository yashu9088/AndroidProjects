package com.example.mad;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.mad.DB.DBHelper;

public class MainActivity7 extends AppCompatActivity {
    Spinner spinner3,spinner4;
    String value3,value4;
    EditText lname , lage, lphone;
    Button submit2;
    DBHelper DB;

    String[] place = {"Mangalore","Bantval","Puttur","Beltangadi","Sulya"};
    String[] work = {"Agriculture Worker", "Mistri","Painter","Plumber","Electrician"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);

        spinner3=findViewById(R.id.place2);
        spinner4=findViewById(R.id.work2);



        submit2 = findViewById(R.id.submit2);
        DB = new DBHelper(this);

        lname=findViewById(R.id.name2);
        lage=findViewById(R.id.age2);
        lphone=findViewById(R.id.phone2);




        ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity7.this, android.R.layout.simple_spinner_item,place);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3.setAdapter(adapter);

        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
                value3 = parent.getItemAtPosition(position).toString();
                Toast.makeText(MainActivity7.this,value3,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(MainActivity7.this, android.R.layout.simple_spinner_item,work);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner4.setAdapter(adapter1);

        spinner4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
                value4 = parent.getItemAtPosition(position).toString();
                Toast.makeText(MainActivity7.this,value4,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        submit2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = lname.getText().toString();
                String phone = lphone.getText().toString();
                String age = lage.getText().toString();
                String place = value3;
                String work = value4;

                Boolean checkinsertdata = DB.insertlabourdata(name,work,place,age,phone);
                if(checkinsertdata==true){
                    Toast.makeText(MainActivity7.this,"UPDATED",Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity7.this,"UPDATE FAILED",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }








}