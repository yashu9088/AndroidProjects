package com.example.mad;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.mad.DB.DBHelper;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity5 extends AppCompatActivity {
    EditText pname , page, pphone;
    String value1,value2;
    Button submit1;
    DBHelper DB;

    Spinner spinner1,spinner2;

    String[] place = {"Mangalore","Bantval","Puttur","Beltangadi","Sulya"};
    String[] work = {"Agriculture Worker", "Mistri","Painter","Plumber","Electrician"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        spinner1=findViewById(R.id.place1);
        spinner2=findViewById(R.id.work1);
        submit1 = findViewById(R.id.submit1);
        DB = new DBHelper(this);

        pname=findViewById(R.id.name1);
        page=findViewById(R.id.age1);
        pphone=findViewById(R.id.phone1);




        ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity5.this, android.R.layout.simple_spinner_item,place);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter);

        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
                value1 = parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(MainActivity5.this, android.R.layout.simple_spinner_item,work);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter1);

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
                value2 = parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        submit1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name = pname.getText().toString();
                String phone = pphone.getText().toString();
                String age = page.getText().toString();
                String place = value1;
                String work = value2;


                if(valid(phone)){
                    Boolean checkinsertdata = DB.insertpersondata(name,work,place,age,phone);
                    if(checkinsertdata==true){
                        Toast.makeText(MainActivity5.this,"UPDATED",Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(MainActivity5.this,"UPDATE FAILED",Toast.LENGTH_SHORT).show();
                    }

                }
                else{
                    Toast.makeText(MainActivity5.this,"Invalid Phone no",Toast.LENGTH_SHORT).show();
                }



            }
        });

    }

    private boolean valid(String phone) {
        Pattern ptern;
        Matcher math;
        String str = "(?=.*[0-9]).{9}";
        ptern = Pattern.compile(str);
        math = ptern.matcher(phone);
        return  math.matches();
    }


}