package com.example.mad;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class admin_login extends AppCompatActivity {
EditText name,password;
Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);


        name = findViewById(R.id.admin_name);
        password = findViewById(R.id.admin_password);
        b1=findViewById(R.id.admin_submit);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s1= name.getText().toString();
                String s2 = password.getText().toString();
                String s3 ="admin";
                if(s1.equals(s3)&& s2.equals(s3)){
                    Intent intent = new Intent(admin_login.this,admin_delete_option.class);
                    startActivity(intent);
                }
            }
        });
    }
}