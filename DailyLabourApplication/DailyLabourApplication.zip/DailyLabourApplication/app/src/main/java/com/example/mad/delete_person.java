package com.example.mad;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mad.DB.DBHelper;

public class delete_person extends AppCompatActivity {
    EditText e1;
    Button b1, deleteAllP;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_person);
        DB=new DBHelper(this);
        e1 = findViewById(R.id.delete_person_name);
        b1 = findViewById(R.id.delete_person_button);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = e1.getText().toString();
                Boolean checkdeletedata = DB.deletePerson(name);
                if(checkdeletedata==true)
                    Toast.makeText(delete_person.this,"DELETED",Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(delete_person.this,"DELETE FAILED",Toast.LENGTH_SHORT).show();
            }
        });


    }

//    public void d_person(View view) {
//
//    String name = e1.getText().toString();
//        DB.deletePerson(name);
//    }
}