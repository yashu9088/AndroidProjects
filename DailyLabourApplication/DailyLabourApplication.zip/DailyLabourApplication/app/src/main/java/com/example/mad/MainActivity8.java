package com.example.mad;




import android.content.Intent;
import android.database.Cursor;
import android.graphics.RenderNode;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.mad.DB.DBHelper;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

public class MainActivity8 extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<String> name,work, address,age, phone;
    DBHelper DB;
    MyAdapter2 adapter;
    ImageView back,add;

    LinearLayout contentView;

    static final float END_SCALE = 0.7f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list);
        recyclerView = findViewById(R.id.list_w);
        DB = new DBHelper(this);
        name = new ArrayList<>();
        work = new ArrayList<>();
        address = new ArrayList<>();
        age = new ArrayList<>();
        phone = new ArrayList<>();
        recyclerView = findViewById(R.id.list_w);
        contentView=findViewById(R.id.content);
        //add=findViewById(R.id.add);

        //back=findViewById(R.id.back);
        adapter = new MyAdapter2(this, name,work, address, age,phone);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        displaydata();

//        add.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent=new Intent(list_contacts.this, login_admin.class);
//                startActivity(intent);
//            }
//        });
//
//        back.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent=new Intent(list_contacts.this,Home.class);
//                startActivity(intent);
//            }
//        });


    }



    private void displaydata() {

        Cursor cursor = DB.getdatap();
        if(cursor.getCount()==0)
        {
            Toast.makeText(MainActivity8.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        }
        else
        {
            while(cursor.moveToNext())
            {
                name.add(cursor.getString(0));
                work.add(cursor.getString(1));
                address.add(cursor.getString(2));
                age.add(cursor.getString(3));
                phone.add(cursor.getString(4));
            }
        }

    }

    public void call(View view) {

    }


}