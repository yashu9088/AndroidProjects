package com.example.mad;



import android.content.Intent;
import android.database.Cursor;
import android.graphics.RenderNode;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.mad.DB.DBHelper;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

public class MainActivity6 extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<String> name,work, address,age, phone;
    DBHelper DB;
    MyAdapter adapter;
    ImageView back,add;
//    ImageButton call;
    LinearLayout contentView;

    static final float END_SCALE = 0.7f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list);
        recyclerView = findViewById(R.id.list_w);


//        call = findViewById(R.id.call_button);






        DB = new DBHelper(this);
        name = new ArrayList<>();
        work = new ArrayList<>();
        address = new ArrayList<>();
        age = new ArrayList<>();
        phone = new ArrayList<>();
        recyclerView = findViewById(R.id.list_w);
        contentView=findViewById(R.id.content);
        //add=findViewById(R.id.add);

        //back=findViewById(R.id.back);
        adapter = new MyAdapter(this, name,work, address, age,phone);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        displaydata();


//
//        call.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                Intent intent = new Intent(Intent.ACTION_CALL);
//
//            }
//        });













    }



    private void displaydata() {

        Cursor cursor = DB.getdatal();
        if(cursor.getCount()==0)
        {
            Toast.makeText(MainActivity6.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        }
        else
        {
            while(cursor.moveToNext())
            {
                name.add(cursor.getString(0));
                work.add(cursor.getString(1));
                address.add(cursor.getString(2));
                age.add(cursor.getString(3));
                phone.add(cursor.getString(4));
            }
        }

    }


//    public void call(View view) {
//
//    }



}