package com.example.mad.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) {
        super(context, "A.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create table person(pname TEXT, pplace TEXT,pwork TEXT,page TEXT,pphone TEXT)");
        DB.execSQL("create table labour(lname TEXT, lplace TEXT,lwork TEXT,lage TEXT,lphone TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop Table if exists person");
        DB.execSQL("drop Table if exists labour");
    }

    public Boolean insertpersondata(String pname, String pplace,String pwork, String page, String pphone){
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("pname",pname);
        contentValues.put("pplace",pplace);
        contentValues.put("pwork",pwork);
        contentValues.put("page",page);
        contentValues.put("pphone",pphone);
        long result = DB.insert("person",null,contentValues);
        if(result==-1) {
            return false;
        }
        else
        {
            return true;
        }

    }


    public Boolean insertlabourdata(String lname, String lplace,String lwork, String lage, String lphone){
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("lname",lname);
        contentValues.put("lplace",lplace);
        contentValues.put("lwork",lwork);
        contentValues.put("lage",lage);
        contentValues.put("lphone",lphone);
        long result = DB.insert("labour",null,contentValues);
        if(result==-1) {
            return false;
        }
        else
        {
            return true;
        }

    }


    public Boolean deletePerson(String pname)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("select * from person where pname = ?",new String[]{pname});
        if(cursor.getCount()>0) {
            long result = DB.delete("person", "pname=?", new String[]{pname});

            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Boolean deleteLabour(String name)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("select * from labour where lname = ?",new String[]{name});
        if(cursor.getCount()>0) {
            long result = DB.delete("labour", "lname=?", new String[]{name});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }



//public void deletealllabour(){
//
//    SQLiteDatabase DB = this.getWritableDatabase();
//    Cursor cursor = DB.rawQuery("select * from labour ",);
//    if(cursor.getCount()>0) {
//        long result = DB.delete("labour", 1,);
//        if (result == -1) {
//            return false;
//        } else {
//            return true;
//        }
//    } else {
//        return false;
// }
//
//}



















    public Cursor getdatap()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from person",null);
        return cursor;
    }

    public Cursor getdatal()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from labour",null);
        return cursor;
    }

}
